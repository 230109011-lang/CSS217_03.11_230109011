package task5;

// Bridge: Implementor interface (where the data is stored)
public interface StorageDriver {
    byte[] loadRawBlob(String resourceUri);

    String getStorageType();
}
