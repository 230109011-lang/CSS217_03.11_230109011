package task5;

// Bridge: Abstraction (what kind of media it is)
public abstract class DigitalAsset {
    protected final StorageDriver driver; // bridge link
    protected final String assetPath;

    public DigitalAsset(StorageDriver driver, String assetPath) {
        this.driver = driver;
        this.assetPath = assetPath;
    }

    public abstract void render();
}
