package task3;

// Sends only between 09:00 and 17:00, except emergencies (severity >= 5)
public class BusinessHoursStrategy implements DispatchStrategy {
    @Override
    public boolean shouldDispatch(int severityLevel, int currentHour) {
        // High severity overrides the business hours rule
        if (severityLevel >= 5) return true;
        return (currentHour >= 9 && currentHour <= 17);
    }

    @Override
    public String getStrategyName() {
        return "BUSINESS_HOURS_ONLY (09:00 - 17:00)";
    }
}
