package task3;

// Strategy: decides if an alert may be sent right now
public interface DispatchStrategy {
    boolean shouldDispatch(int severityLevel, int currentHour);

    String getStrategyName();
}
