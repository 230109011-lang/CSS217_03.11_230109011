package task3;

// Bridge: Implementor interface (how the message is delivered)
public interface MessageChannel {
    void transmit(String recipient, String message);
}
