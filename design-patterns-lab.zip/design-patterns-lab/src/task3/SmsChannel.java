package task3;

public class SmsChannel implements MessageChannel {
    @Override
    public void transmit(String recipient, String message) {
        // SMS is one line, so new lines are replaced
        String condensed = message.replace("\n", " -- ");
        System.out.printf("[SMS PROTOCOL -> %s] %s%n", recipient, condensed);
    }
}
