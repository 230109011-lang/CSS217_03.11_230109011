package task1;

// Strategy: interface for different report formats
public interface ReportFormatter {
    String format(String title, String[] headers, String[][] rows);
}
