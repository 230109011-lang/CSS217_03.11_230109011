package task1;

// Decorator pattern: Component interface
public interface Exporter {
    void export(String destination, String data);
}
