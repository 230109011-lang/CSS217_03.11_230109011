package task4;

// Target interface
public interface PricingService {
    double calculateTotal();

    String getReceiptBreakdown();
}
