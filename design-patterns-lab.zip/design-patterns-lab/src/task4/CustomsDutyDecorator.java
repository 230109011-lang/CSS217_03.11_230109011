package task4;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class CustomsDutyDecorator extends PricingDecorator {

    public CustomsDutyDecorator(PricingService wrapped) {
        super(wrapped);
    }

    @Override
    public double calculateTotal() {
        double subtotal = super.calculateTotal();
        // 8.5% tax, rounded to 2 decimals.
        // BigDecimal is used because double gives 157.32 for 157.325 (floating point error)
        BigDecimal total = BigDecimal.valueOf(subtotal).multiply(BigDecimal.valueOf(1.085));
        return total.setScale(2, RoundingMode.HALF_UP).doubleValue();
    }

    @Override
    public String getReceiptBreakdown() {
        return super.getReceiptBreakdown() + " + [Customs Duty: 8.5%]";
    }
}
